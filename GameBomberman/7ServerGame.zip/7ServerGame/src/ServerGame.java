

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

/**
 * 
 * @author pacopulido
 * 
 * Recibe el arraylist de los sockets de los jugadores
 * 
 * Server que se arranca cuando se han obtenido 
 * las conexiones de los jugadores.
 * 
 * Se dedica a recibir la tecla pulsada de un jugador y
 * renviarsela a todos. Así con todos los jugadores.
 * El protocolo indica que en el paquete viene 
 * x,y,z
 * x = numero del jugador
 * y =(-1,0,1) izquierda nada derecha
 * z =(-1,0,1) arriba nada abajo
 * Ejemplo: paquete = 4,1,0 jugador 4 derecha
 * 
 * Aunque a este servidor le importa poco lo que viene,
 * pues lo que le llega, tal cual lo reenvia a todos
 * Son los clientes los que cuando le lleguen deben actualizar
 * la vista según el movimiento del jugador en cuestión.
 *
 */
public class ServerGame extends JFrame implements Runnable{

	private static final long serialVersionUID = 1L;
	private static final int PORTSERVER = 6060;
	private static final int PORTCLIENT = 6969;
	private JPanel contentPane;
	private DatagramSocket socketUDP=null;
	private String cadena;
	private byte[] enviados;	
	private byte[] recibidos;
	private DatagramPacket dprecibo;
	private DatagramPacket dpenvio;
	private ArrayList<Socket> sockets;
	private JTextArea textArea;
	private Thread hilo;
	/**
	 * Create the frame.
	 */
	public ServerGame(ArrayList<Socket> sockets) {
		this.sockets = sockets;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		textArea = new JTextArea();
		textArea.setEditable(false);
		JScrollPane jscrollpane = new JScrollPane(textArea);
		jscrollpane.setBounds(0, 0, 450, 300);
		contentPane.add(jscrollpane);
		try {
			socketUDP = new DatagramSocket(PORTSERVER);
		} catch (SocketException e) {
			e.printStackTrace();
		}
		setVisible(true);
		// Lanzamos el hilo que acepta nuevas conexiones
		// Recordamos que el hilo es la propia clase runnable (this)
		hilo = new Thread(this);
		hilo.setName("Server");
		hilo.start();
	}

	@Override
	public void run() {
		// Recibiendo teclas de los clientes
		while (true) {
			recibidos = new byte[1024];
			// Recibimos del Cliente
			dprecibo= new DatagramPacket(recibidos, recibidos.length);
			try {
				socketUDP.receive(dprecibo);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (isJugador(dprecibo.getAddress().getHostAddress())) {
				cadena = new String(dprecibo.getData());
				System.out.println(cadena);
				if (cadena.contains("bye")) {break;}
				enviarall(cadena);
			} else continue;
		}
		
		// Cerrando socket
		socketUDP.close();
		
	}

	private boolean isJugador(String host) {
		for (Socket socket:sockets) {
			String hostAdddress = socket.getInetAddress().getHostAddress();
			if ( hostAdddress.equals(host)) { 
				return true;
			}
		}
		return false;
	}

	private void enviarall(String cadena) {
		textArea.append(cadena+"\n");
		enviados = cadena.getBytes();
		// Enviamos a todos los Clientes
		for (Socket socket:sockets) {
			dpenvio= new DatagramPacket(enviados, enviados.length, socket.getInetAddress(), PORTCLIENT);
			try {
				socketUDP.send(dpenvio);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
