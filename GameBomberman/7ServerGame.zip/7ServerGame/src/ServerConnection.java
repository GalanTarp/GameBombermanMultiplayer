

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * 
 * @author pacopulido
 * Ventana del Servidor para aceptar conexiones TCP
 *
 */
public class ServerConnection extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private ServerSocket serverSocket;
	private JLabel lblmsg;
	private Thread hilo;
	private int countConex=0;
	private Socket socket;
	private ArrayList<Socket> sockets;
	private PrintWriter pw;
	private static final int PORTSERVER = 6000;
	private static final int MAXCLI = 1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerConnection frame = new ServerConnection();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ServerConnection() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Start Server");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				start();
			}
		});
		btnNewButton.setBounds(5, 5, 440, 29);
		contentPane.add(btnNewButton);
		
		lblmsg = new JLabel("");
		lblmsg.setBounds(15, 46, 429, 16);
		contentPane.add(lblmsg);
	}

	protected void start() {
		// Iniciamos el server
		try {
			serverSocket = new ServerSocket(PORTSERVER);
			System.out.println("server started...");
			lblmsg.setText("Esperando jugadores....0/"+MAXCLI);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		sockets = new ArrayList<Socket>();
		// Lanzamos el hilo que acepta nuevas conexiones
		// Recordamos que el hilo es la propia clase runnable (this)
		hilo = new Thread(this);
		hilo.setName("Server");
		hilo.start();
	}

	@Override
	public void run() {
		while (countConex < MAXCLI) {
			try {
				socket = serverSocket.accept();
				// Avisemos al resto del nuevo cliente
				enviar("Conexión aceptada. Jugador:"+countConex, socket);
				countConex++;
				lblmsg.setText("Esperando jugadores...."+countConex+"/"+MAXCLI);
			} catch (IOException e) {
				break; // Problemas => a la calle
			}
			System.out.println(socket.getInetAddress().getHostAddress());
			sockets.add(socket);
		}
		lblmsg.setText("Ya tenemos los " + MAXCLI + "jugagores.");
		System.out.println("Ya tenemos los " + MAXCLI + "jugagores.");
		enviarall("Ya tenemos todos los jugadores. Comencemos en 1,2,3.");
		
		try {
			Thread.sleep(3000);
			new ServerGame(sockets);
			enviarall("started");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	private void enviar(String msg, Socket socket) {
		try {
			pw = new PrintWriter(socket.getOutputStream());
			pw.write(msg + "\n");
			pw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void enviarall(String msg) {
		for (Socket socket:sockets) {
			try {
				pw = new PrintWriter(socket.getOutputStream());
				pw.write(msg + "\n");
				pw.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	
	}
}
