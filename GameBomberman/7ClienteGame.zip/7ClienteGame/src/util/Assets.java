package util;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Assets {
	public static Image bomberman;
	public static Image bombermanrojo;
	public static Image bombermanverde;
	public static Image bombermanazul;
	public static Image bomba;
	public static Image explosion;
	public static Image mapa;
	public static Image bloque;
	
	
	public static void loadAssets() {
		
		bomberman = (new ImageIcon(Assets.class.getResource("/recursos/Bomberman.png"))).getImage();
		bombermanrojo = (new ImageIcon(Assets.class.getResource("/recursos/Bombermanrojo.png"))).getImage();
		bombermanverde = (new ImageIcon(Assets.class.getResource("/recursos/Bombermanverde.png"))).getImage();
		bombermanazul = (new ImageIcon(Assets.class.getResource("/recursos/Bombermanazul.png"))).getImage();
		bomba = (new ImageIcon(Assets.class.getResource("/recursos/bomba.png"))).getImage();
		explosion = (new ImageIcon(Assets.class.getResource("/recursos/explosion.png"))).getImage();
		mapa = (new ImageIcon(Assets.class.getResource("/recursos/mapajugable.png"))).getImage();
		bloque = (new ImageIcon(Assets.class.getResource("/recursos/bloque.png"))).getImage();
	}
}
