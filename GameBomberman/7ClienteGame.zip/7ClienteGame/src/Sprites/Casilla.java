package Sprites;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.Serializable;

import util.Assets;

public class Casilla implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int x, y, frame = 0;
	public int ANCHO = 48, ALTO = 45;
	public boolean muro, bomba, bloque, explota, puedo;
	transient private Image bloqueimg;
	private int COLUMNAS = 4, Anchoimg = 76 , Altoimg = 19, anchoSeccion = Anchoimg/COLUMNAS;
	
	
	
	
	
	public Casilla(int x, int y, boolean muro) {
		super();
		this.x = x;
		this.y = y;
		this.muro = muro;
		this.bomba = false;
		this.bloque = false;
		explota = false;
		puedo = true;
		bloqueimg = Assets.bloque;
	}


	public void draw(Graphics g) {
		if(bloque) {
			g.drawImage(bloqueimg, x, y, x+ANCHO , y+ALTO, 
					frame*anchoSeccion, 0, (frame+1)*anchoSeccion, Altoimg, null);
			if(frame>=4) {
				bloque=false;
			}
		}
		
	}
	
	public int colisioncuenta(Bomberman bomber) {
		int result = 0;
		Rectangle recBomberman = new Rectangle(bomber.xCuadrado, bomber.yCuadrado, bomber.anchoCuadrado, bomber.altoCuadrado);
		for (int i = 0; i < ANCHO; i++) {
			for (int j = 0; j < ALTO; j++) {
				Rectangle recCasilla = new Rectangle(x+i, y+j, 1,1);
				if(recBomberman.intersects(recCasilla)){
					result++;
				}
			}
		}
		return result;
	}
}
