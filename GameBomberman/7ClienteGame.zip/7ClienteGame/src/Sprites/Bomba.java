package Sprites;

import java.awt.Graphics;
import java.awt.Image;

import util.Assets;

public class Bomba {

	public int xBomba, yBomba, potencia, i, j, up, right, down, left;
	private Image bombaimg, explosionimg;
	private int Columnas = 3, anchoImg = 60, altoImg = 20, ANCHO = 48, ALTO=45,
			Columnasex = 4,Filasex = 9, anchoImgex = 68, altoImgex = 153; 
	private int anchoSeccion = anchoImg/Columnas, altoSeccion = altoImg,
			anchoSeccionex = anchoImgex/Columnasex, altoSeccionex = altoImgex/Filasex;
	public int frame=0, direccion=1, contador=60;
	public boolean explota = false, acabo = false, dano = false;
	public int name;
	
	
	
	public Bomba(int x, int y, int name, int p, int i, int j) {
		bombaimg = Assets.bomba;
		explosionimg = Assets.explosion;
		xBomba = x;
		yBomba = y;
		this.name = name;
		this.i = i;
		this.j = j;
		potencia = p;
		
	}

	
	public void draw(Graphics g) {
//		g.drawImage(Bombaimg, xBomba, yBomba, xBomba + 100, yBomba+ 100,
//				0, 0, anchoSeccion, altoSeccion, null);
		if(!explota) {
			g.drawImage(bombaimg, xBomba, yBomba, xBomba+ANCHO , yBomba+ALTO, 
					(frame%Columnas)*anchoSeccion, 0, (frame%Columnas+1)*anchoSeccion, altoSeccion, null);			
			if (frame==2) {
				direccion = -1;		
			}
			if (frame==0) {
				direccion = 1;		
			}
			if(contador<=0) {
				if(contador==0) {
					dano = true;
					frame=0;
					direccion=1;
					contador--;
				}
				
			}else {
				contador--;
			}
		}else {
			g.drawImage(explosionimg, xBomba, yBomba, xBomba+ANCHO , yBomba+ALTO, 
					(frame%Columnasex)*anchoSeccionex, 0, (frame%Columnasex+1)*anchoSeccionex, altoSeccionex, null);			
			for (int i = 0; i < up; i++) {
				//Explosion arriba
				if(i==up-1){
					//punto final de la explosion
					g.drawImage(explosionimg, xBomba, yBomba-(ALTO*(i+1)), xBomba+ANCHO , yBomba-(ALTO*i), 
							(frame%Columnasex)*anchoSeccionex, 5 * altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 6 * altoSeccionex, null);
				}else {
					g.drawImage(explosionimg, xBomba, yBomba-(ALTO*(i+1)), xBomba+ANCHO , yBomba-(ALTO*i), 
							(frame%Columnasex)*anchoSeccionex, altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 2 * altoSeccionex, null);
				}
			}
			for (int i = 0; i < right; i++) {
				//Explosion derecha
				if(i==right-1){
					//punto final de la explosion
					g.drawImage(explosionimg, xBomba+ANCHO*(i+1), yBomba, xBomba+ANCHO*(i+2) , yBomba+ALTO, 
							(frame%Columnasex)*anchoSeccionex, 6*altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 7 * altoSeccionex, null);			
				}else {
					g.drawImage(explosionimg, xBomba+ANCHO*(i+1), yBomba, xBomba+ANCHO*(i+2) , yBomba+ALTO, 
							(frame%Columnasex)*anchoSeccionex, 2*altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 3 * altoSeccionex, null);			
				}
			}
			
			for (int i = 0; i < down; i++) {
				//Explosion abajo
				if(i==down-1){
					//punto final de la explosion
					g.drawImage(explosionimg, xBomba, yBomba+ALTO*(i+1), xBomba+ANCHO , yBomba+ALTO*(i+2), 
							(frame%Columnasex)*anchoSeccionex, 7*altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 8 * altoSeccionex, null);			
				}else {
					g.drawImage(explosionimg, xBomba, yBomba+ALTO*(i+1), xBomba+ANCHO , yBomba+ALTO*(i+2), 
							(frame%Columnasex)*anchoSeccionex, 3*altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 4 * altoSeccionex, null);			
				}
			}
			for (int i = 0; i < left; i++) {
				//Explosion izquierda
				if(i==left-1){
					//punto final de la explosion
					g.drawImage(explosionimg, xBomba-ANCHO*(i+1), yBomba, xBomba-(ANCHO*i) , yBomba+ALTO, 
							(frame%Columnasex)*anchoSeccionex, 8*altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 9 * altoSeccionex, null);			
				}else {
					g.drawImage(explosionimg, xBomba-ANCHO*(i+1), yBomba, xBomba-(ANCHO*i) , yBomba+ALTO, 
							(frame%Columnasex)*anchoSeccionex, 4*altoSeccionex, (frame%Columnasex+1)*anchoSeccionex, 5 * altoSeccionex, null);			
				}
			}
			if (frame>=4) {
				acabo=true;		
			}
		}
	}

}
