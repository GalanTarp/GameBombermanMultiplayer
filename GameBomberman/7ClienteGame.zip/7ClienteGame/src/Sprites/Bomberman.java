package Sprites;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.Serializable;

import util.Assets;

public class Bomberman implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int xBomberman, yBomberman;
	public int MaxWidth, MaxHeight;
	transient public Image bombermanimg;
	private int Columnas = 7, Filas = 4, anchoImg = 224, altoImg = 128, ANCHO = 64, ALTO=64; 
	private int anchoSeccion = anchoImg/Columnas, altoSeccion = altoImg/Filas;
	public int frame=0, direccion=2;
	public int xCuadrado, yCuadrado, anchoCuadrado = ANCHO/2, altoCuadrado = ALTO/2;
	
	public int maxBombs, potencia, bombas, vidas;
	public int name;
	
	
	public Bomberman() {
		bombermanimg = Assets.bomberman;
	}
	public Bomberman(int MaxW,int MaxH, int x, int y, int name) {
		MaxWidth = MaxW;
		MaxHeight = MaxH;
		bombas = 0;
		maxBombs = 2;
		potencia = 4;
		vidas=1;
		xBomberman = x-ANCHO/4;
		yBomberman = y-ALTO/4-5;
		this.name = name;
		switch (name) {
		case 0:
			bombermanimg = Assets.bomberman;
			break;

		case 1:
			bombermanimg = Assets.bombermanrojo;
			break;

		case 2:
			bombermanimg = Assets.bombermanverde;
			break;

		case 3:
			bombermanimg = Assets.bombermanazul;
			break;

		default:
			break;
		}
	}

	

	public void update() { 
		xCuadrado = xBomberman+ANCHO/4;
		yCuadrado = yBomberman+ALTO/4+5;
	}
	
	public void draw(Graphics g) {
		if(vidas>0) {
			g.drawImage(bombermanimg, xBomberman, yBomberman, xBomberman+ANCHO , yBomberman+ALTO, 
					(frame%Columnas)*anchoSeccion, direccion*altoSeccion, (frame%Columnas+1)*anchoSeccion, (direccion+1)*altoSeccion, null);			
			
			if (frame==6) {
				frame=0;		
			}
		}
		
	}
	
	public void left(){
		if(xBomberman>=-ANCHO/4+5) {
			xBomberman-=5;
		}
	}
	
	public void right(){
		if(xBomberman<=MaxWidth-ANCHO*3/4 -10) {
			xBomberman+=5;
		}
	}
	
	public void up(){
		if(yBomberman>=-ALTO/4+5) {
			yBomberman-=5;
		}
	}
	
	public void down(){
		if(yBomberman<=MaxHeight-ALTO*3/4 -10) {
			yBomberman+=5;
		}
	}
	
	
	public boolean colision(Casilla casilla) {
		Rectangle recBomberman = new Rectangle(xCuadrado, yCuadrado, anchoCuadrado,altoCuadrado);
		Rectangle recCasilla = new Rectangle(casilla.x, casilla.y, casilla.ANCHO, casilla.ALTO);
		return recBomberman.intersects(recCasilla);
	}
	
	public boolean colisionH(Casilla casilla, boolean DoI) {
		Rectangle recBomberman;
		if(DoI) {
			recBomberman = new Rectangle(xCuadrado-5, yCuadrado+5, 1,altoCuadrado-10);
		}else {
			recBomberman = new Rectangle(xCuadrado+anchoCuadrado-1+5, yCuadrado+5, 1,altoCuadrado-10);
		}
		
		Rectangle recCasilla = new Rectangle(casilla.x, casilla.y, casilla.ANCHO, casilla.ALTO);
		return recBomberman.intersects(recCasilla);
	}
	
	public boolean colisionV(Casilla casilla, boolean DoI) {
		Rectangle recBomberman;
		if(DoI) {
			recBomberman = new Rectangle(xCuadrado+5, yCuadrado-6, anchoCuadrado-10,1);
		}else {
			recBomberman = new Rectangle(xCuadrado+5, yCuadrado+altoCuadrado+6, anchoCuadrado-10,1);
		}
		
		Rectangle recCasilla = new Rectangle(casilla.x, casilla.y, casilla.ANCHO, casilla.ALTO);
		return recBomberman.intersects(recCasilla);
	}


}
