

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Sprites.Bomba;
import Sprites.Bomberman;
import Sprites.Casilla;
import util.Assets;
import util.InputHandler;

public class ClientGame extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	private static final int PORTSERVER = 6060;
	private static final int PORTCLIENT = 6969;
	
	private DatagramSocket socketUDP=null;
	private byte[] enviados;	
	private byte[] recibidos;
	private DatagramPacket dprecibo;
	private DatagramPacket dpenvio;
	private JPanel contentPane;
	private int jugador;
	private InetAddress direccion;
	private Thread hilo;
	
	private int ANCHO=750, ALTO=500;
	private BufferedImage bufferedImage;
	private InputHandler input;
	public boolean isRunning = true;
	
	private ArrayList<Bomberman> bombermans;
	private Casilla[][] tablero;
	public ArrayList<Bomba> bombas;
	
	//Otros
	private int nanimacion;
	private Image mapa;
	private boolean muerto;


	public ClientGame(int jugador) {
		//base para cualquier JFrame
		this.jugador = jugador;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, ANCHO, ALTO);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//Cargo Assets y preparo para poder ser un videojuego
		Assets.loadAssets();
		bufferedImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);

		//para poder introducir las teclas
		input = new InputHandler(this);
		// Objetos
		bombermans = new ArrayList<Bomberman>();
		tablero = new Casilla[10][15];
		bombas = new ArrayList<Bomba>();
		rellenotablero();
		
		//a�ado los 4 juegadores
		bombermans.add(new Bomberman(720+8 , 450+30, tablero[1][0].x, tablero[1][0].y, 0));
		bombermans.add(new Bomberman(720+8 , 450+30, tablero[9][0].x, tablero[9][0].y, 1));
		bombermans.add(new Bomberman(720+8 , 450+30, tablero[1][14].x, tablero[1][14].y, 2));
		bombermans.add(new Bomberman(720+8 , 450+30, tablero[9][14].x, tablero[9][14].y, 3));
		
		//Otros
		nanimacion=0;
		mapa = Assets.mapa;
		muerto = false;

		setVisible(true);
		
		//preparo para poder hacer la comunicacion UDP
		try {
			socketUDP = new DatagramSocket(PORTCLIENT);
		} catch (SocketException e) {
			e.printStackTrace();
		}
		try {
			direccion = InetAddress.getByName("192.168.1.110");
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}
		
		setVisible(true);
		
		//Inicio el hilo
		hilo = new Thread(this);
		hilo.start();
		
		//Inicio el motor grafico a 30 FPS
		new GameLoop(this).start();
	}
	
	private void rellenotablero() {
		//Relleno el tablero con las casillas segun sean muros, bloques destructibles o esten libres
		//en las esquinas donde empiezan los jugadores
		int yaux=30;
		//relleno muros
		for (int i = 0; i < tablero.length; i++) {
			int xaux=8;
			for (int j = 0; j < tablero[i].length; j++) {
				if(i==0) {
					tablero[i][j] = new Casilla(xaux, yaux, true);
				}else if ( i%2==0){
					if(j%2!=0) {
						tablero[i][j] = new Casilla(xaux, yaux, true);
					}else {
						tablero[i][j] = new Casilla(xaux, yaux, false);
					}
				}else {
					tablero[i][j] = new Casilla(xaux, yaux, false);
				}
				xaux+=48;
			}
			yaux+=45;
		}
		
		//relleno bloques donde no haya muros ni en las esquinas
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if(!tablero[i][j].muro) {
					if(i==1 || i == tablero.length-1) {
						if (j<2 || j > tablero[i].length-3) {
							tablero[i][j].bloque = false;
						}else {
							tablero[i][j].bloque = true;
						}
					}else if(i==2 || i == tablero.length-2) {
						if (j<1 || j > tablero[i].length-2) {
							tablero[i][j].bloque = false;
						}else {
							tablero[i][j].bloque = true;
							
						}
					}else {
						tablero[i][j].bloque = true;
						
					}
				}
			}
		}
	}
	
	void update() {
		
		Bomberman mibomberman = null;
		
		for (Bomberman bomberman : bombermans) {
			//Cual es tu Bomberman
			if (bomberman.name ==jugador) {
				mibomberman = bomberman;
			}
		}
		
		if(mibomberman.vidas>0) {
			// handle inputs
			if (input.isKeyDown(KeyEvent.VK_RIGHT)) {
				
				if(puedoDerecha(mibomberman)) {
					//Mandar al server
					enviar(jugador + " DERECHA");
				}
			}
			if (input.isKeyDown(KeyEvent.VK_LEFT)) {
				if(puedoIzquierda(mibomberman)) {
					//Mandar al server
					enviar(jugador + " IZQUIERDA");
				}
			}
			if (input.isKeyDown(KeyEvent.VK_UP)) {
				if (puedoArriba(mibomberman)) {	
					//Mandar al server
					enviar(jugador + " ARRIBA");
				}
			}
			if (input.isKeyDown(KeyEvent.VK_DOWN)) {
				if(puedoAbajo(mibomberman)) {
					//Mandar al server
					enviar(jugador + " ABAJO");
				}
			}
			if (input.isKeyDown(KeyEvent.VK_SPACE)) {
				if (puedoBomba(mibomberman)) {
					//Mandar al server
					enviar(jugador + " BOMBA");
				}
			}
		}else {
			muerto=true;
		}
		
		for (Bomberman bomberman : bombermans) {
			bomberman.update();
		}
		
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if(tablero[i][j].bomba && tablero[i][j].puedo) {
					if(!mibomberman.colision(tablero[i][j])) {
						tablero[i][j].puedo=false;
					}
				}
			}
		}
	}


	private boolean puedoDerecha(Bomberman bomberman) {
		//Indica si puedo mover mi bomberman a la derecha
		boolean solucion= true;
		
		//recorrer tablero
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if(bomberman.colisionH(tablero[i][j], false) && tablero[i][j].muro) {
					solucion =  false;
				}else if(bomberman.colisionH(tablero[i][j], false) && tablero[i][j].bloque) {
					solucion = false;
				}else if(bomberman.colisionH(tablero[i][j], false) && !tablero[i][j].puedo) {
					solucion = false;
				}
			}
		}
			
		return solucion;
	}
	
	private boolean puedoIzquierda(Bomberman bomberman) {
		//Indica si puedo mover mi bomberman a la izquierda
		boolean solucion= true;
		
		//recorrer tablero
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if(bomberman.colisionH(tablero[i][j], true) && tablero[i][j].muro) {
					solucion =  false;
				}else if(bomberman.colisionH(tablero[i][j], true) && tablero[i][j].bloque) {
					solucion = false;
				}else if(bomberman.colisionH(tablero[i][j], true) && !tablero[i][j].puedo) {
					solucion = false;
				}
			}
		}
			
		return solucion;
	}
	
	private boolean puedoArriba(Bomberman bomberman) {
		//Indica si puedo mover mi bomberman a la arriba
		boolean solucion= true;
		
		//recorrer tablero
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if(bomberman.colisionV(tablero[i][j], true) && tablero[i][j].muro) {
					solucion =  false;
				}else if(bomberman.colisionV(tablero[i][j], true) && tablero[i][j].bloque) {
					solucion = false;
				}else if(bomberman.colisionV(tablero[i][j], true) && !tablero[i][j].puedo) {
					solucion = false;
				}
			}
		}
			
		return solucion;
	}
	
	private boolean puedoAbajo(Bomberman bomberman) {
		//Indica si puedo mover mi bomberman a la abajo
		boolean solucion= true;
		
		//recorrer tablero
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if(bomberman.colisionV(tablero[i][j], false) && tablero[i][j].muro) {
					solucion =  false;
				}else if(bomberman.colisionV(tablero[i][j], false) && tablero[i][j].bloque) {
					solucion = false;
				}else if(bomberman.colisionV(tablero[i][j], false) && !tablero[i][j].puedo) {
					solucion = false;
				}
			}
		}
			
		return solucion;
	}
	
	private boolean puedoBomba(Bomberman bomberman) {
		//Indica si puedo poner una bomba en la casilla en la que me encuentro
		boolean solucion= true;
		

		Casilla aux = casillacorrecta(bomberman);
		if(aux.bomba) {
			solucion =  false;
		}else if(bomberman.bombas>=bomberman.maxBombs) {
			solucion = false;
		}
				
			
		return solucion;
	}
	
	private Casilla casillacorrecta(Bomberman bomberman2) {
		//Analiza todas las casillas con las que tiene contacto el bomberman2 y devuelve la casillla en
		//la que mayor numero de colision tiene
		int posicion = 0;
		ArrayList<Casilla> aux = new ArrayList<Casilla>();
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				if (!tablero[i][j].muro && bomberman2.colision(tablero[i][j])) {
					aux.add(tablero[i][j]);
				}
			}
		}
		ArrayList<Integer> cuenta = new ArrayList<Integer>();
		for (Casilla casilla : aux) {
			cuenta.add(casilla.colisioncuenta(bomberman2));
		}
		int mayor = 0;
		for (int i = 0; i < cuenta.size(); i++) {
			if(cuenta.get(i)>mayor) {
				mayor=cuenta.get(i);
				posicion = i;
			}
		} 
		return aux.get(posicion);
	}
	
	
	void draw() {
		Graphics g = getGraphics();
		Graphics bbg = bufferedImage.getGraphics();
		// Fondo y Logo

		//System.out.println(ANCHO + " " + ALTO);
		//48 x 50
		bbg.setColor(Color.BLACK);
		bbg.fillRect(0, 0, ANCHO, ALTO);
		bbg.drawImage(mapa, 8, 30, 720+8 , 450+30, 
				0, 0, 240, 160, null);			
		
		
		//pinta de manera mas lenta los frame
		nanimacion++;
		if(nanimacion%3==0) {
			for (int i = 0; i < tablero.length; i++) {
				for (int j = 0; j < tablero[i].length; j++) {
					if(tablero[i][j].explota) {
						tablero[i][j].frame++;
					}
				}
			}
			for (Bomberman bomberman : bombermans) {
				bomberman.frame ++;				
			}
			for (Bomba bomba : bombas) {
				bomba.frame += bomba.direccion;
			}
			if(nanimacion >= 60) {
				nanimacion=0;
			}
		}
		for (int i = 0; i < tablero.length; i++) {
			for (int j = 0; j < tablero[i].length; j++) {
				tablero[i][j].draw(bbg);
			}
		}
		for (Bomberman bomberman : bombermans) {
			bomberman.draw(bbg);
		}
		for (int i = 0; i < bombas.size(); i++) {
			if (bombas.get(i).dano) {
				explosion(i);
			}else if(bombas.get(i).acabo) {
				for (Bomberman bomb : bombermans) {
					if(bombas.get(i).name == bomb.name) {
						bomb.bombas--;
					}
				}
				tablero[bombas.get(i).i][bombas.get(i).j].bomba=false;
				tablero[bombas.get(i).i][bombas.get(i).j].puedo=true;
				bombas.remove(i);
			}
			else {
				bombas.get(i).draw(bbg);
			}
			
		}
		
		if(muerto) {
			bbg.setColor( new Color(0,0,0, 127));
			bbg.fillRect( 0, 0, ANCHO, ALTO);
			bbg.setColor(Color.WHITE);
			bbg.setFont(new Font ("SansSerif",Font.BOLD,70));
			bbg.drawString("HAS MUERTO", ANCHO/5, ALTO/2);
		}
		g.drawImage(bufferedImage, 0, 0, this);
	}
	
	
	private void explosion(int bomba) {
		//indica a las bombas hasta donde pueden pintar
		//si es un muro se paran
		//si es un bloque destructible lo destruye y se detiene
		//si es otra bomba la activa
		int arriba=0, derecha=0, abajo=0, izq=0;
		
		
		//arriba
		for (int i = 1; i <= bombas.get(bomba).potencia; i++) {
			if(bombas.get(bomba).i-i>0) {
				if(tablero[bombas.get(bomba).i-i][(bombas.get(bomba).j)].muro) {
					break;
				}else if(tablero[bombas.get(bomba).i-i][(bombas.get(bomba).j)].bloque) {
					arriba++;
					tablero[bombas.get(bomba).i-i][(bombas.get(bomba).j)].explota=true;
					break;
				}else if(tablero[bombas.get(bomba).i-i][(bombas.get(bomba).j)].bomba) {
					arriba++;
					for (Bomba bomba2 : bombas) {
						if(!bomba2.dano && !bomba2.explota) {
							if(bomba2.i == bombas.get(bomba).i-i && bomba2.j == bombas.get(bomba).j) {
								bomba2.dano=true;
								bomba2.frame=0;
								bomba2.direccion=1;
							}
						}
					}
					break;
				}else {
					for (Bomberman bomberman : bombermans) {
						if(bomberman.colision(tablero[bombas.get(bomba).i-i][(bombas.get(bomba).j)])) {
							enviar(bomberman.name + " MUERTO");
						}
					}
					arriba++;
				}
			}
		}
		
		//derecha
		for (int i = 1; i <= bombas.get(bomba).potencia; i++) {
			if(bombas.get(bomba).j+i < tablero[bombas.get(bomba).i].length) {
				if(tablero[bombas.get(bomba).i][(bombas.get(bomba).j+i)].muro) {
					break;
				}else if(tablero[bombas.get(bomba).i][(bombas.get(bomba).j+i)].bloque) {
					derecha++;
					tablero[bombas.get(bomba).i][(bombas.get(bomba).j+i)].explota=true;
					break;
				}else if(tablero[bombas.get(bomba).i][(bombas.get(bomba).j+i)].bomba) {
					derecha++;
					for (Bomba bomba2 : bombas) {
						if(!bomba2.dano && !bomba2.explota) {
							if(bomba2.i == bombas.get(bomba).i && bomba2.j == bombas.get(bomba).j+i && !bomba2.dano) {
								bomba2.dano=true;
								bomba2.frame=0;
								bomba2.direccion=1;
							}
						}
					}
					break;
				}else {
					for (Bomberman bomberman : bombermans) {
						if(bomberman.colision(tablero[bombas.get(bomba).i][(bombas.get(bomba).j+i)])) {
							enviar(bomberman.name + " MUERTO");
						}
					}
					derecha++;
				}
			}
		}
		
		//abajo
		for (int i = 1; i <= bombas.get(bomba).potencia; i++) {
			if(bombas.get(bomba).i+i < tablero.length) {
				if(tablero[bombas.get(bomba).i+i][(bombas.get(bomba).j)].muro) {
					break;
				}else if(tablero[bombas.get(bomba).i+i][(bombas.get(bomba).j)].bloque) {
					abajo++;
					tablero[bombas.get(bomba).i+i][(bombas.get(bomba).j)].explota=true;
					break;
				}else if(tablero[bombas.get(bomba).i+i][(bombas.get(bomba).j)].bomba) {
					abajo++;
					for (Bomba bomba2 : bombas) {
						if(!bomba2.dano && !bomba2.explota) {
							if(bomba2.i == bombas.get(bomba).i+i && bomba2.j == bombas.get(bomba).j && !bomba2.dano) {
								bomba2.dano=true;
								bomba2.frame=0;
								bomba2.direccion=1;
							}
						}
					}
					break;
				}else {
					for (Bomberman bomberman : bombermans) {
						if(bomberman.colision(tablero[bombas.get(bomba).i+i][(bombas.get(bomba).j)])) {
							enviar(bomberman.name + " MUERTO");
						}
					}
					abajo++;
				}
			}
		}
		
		//izquierda
		for (int i = 1; i <= bombas.get(bomba).potencia; i++) {
			if(bombas.get(bomba).j-i>=0) {
				if(tablero[bombas.get(bomba).i][(bombas.get(bomba).j-i)].muro) {
					break;
				}else if(tablero[bombas.get(bomba).i][(bombas.get(bomba).j-i)].bloque) {
					izq++;
					tablero[bombas.get(bomba).i][(bombas.get(bomba).j-i)].explota=true;
					break;
				}else if(tablero[bombas.get(bomba).i][(bombas.get(bomba).j-i)].bomba) {
					izq++;
					for (Bomba bomba2 : bombas) {
						if(!bomba2.dano && !bomba2.explota) {
							if(bomba2.i == bombas.get(bomba).i && bomba2.j == bombas.get(bomba).j-i && !bomba2.dano) {
								bomba2.dano=true;
								bomba2.frame=0;
								bomba2.direccion=1;
							}
						}
					}
					break;
				}else {
					for (Bomberman bomberman : bombermans) {
						if(bomberman.colision(tablero[bombas.get(bomba).i][(bombas.get(bomba).j-i)])) {
							enviar(bomberman.name + " MUERTO");
						}
					}
					izq++;
				}
			}
		}
		bombas.get(bomba).up = arriba;
		bombas.get(bomba).right = derecha;
		bombas.get(bomba).down = abajo;
		bombas.get(bomba).left = izq;
		bombas.get(bomba).dano = false;
		bombas.get(bomba).explota = true;
		
	}

	
	private void enviar(String cadena) {
		enviados = cadena.getBytes();
		dpenvio= new DatagramPacket(enviados, enviados.length, direccion, PORTSERVER);
		try {
			socketUDP.send(dpenvio);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void run() {
		while (true) {
			recibidos = new byte[1024];
			dprecibo= new DatagramPacket(recibidos, recibidos.length);
			try {
				socketUDP.receive(dprecibo);
			} catch (IOException e) {
				e.printStackTrace();
			}
			String resultado = new String(dprecibo.getData()).trim();
			
			
			for (Bomberman bomberman2 : bombermans) {
				if (resultado.contains(Integer.toString(bomberman2.name))){
					if (resultado.contains("DERECHA")) {
						bomberman2.right();
						bomberman2.direccion=1;
					}else if (resultado.contains("IZQUIERDA")) {
						bomberman2.left();
						bomberman2.direccion=3;
					}else if (resultado.contains("ARRIBA")) {
						bomberman2.up();
						bomberman2.direccion=0;
					}else if (resultado.contains("ABAJO")) {
						bomberman2.down();
						bomberman2.direccion=2;
					}else if (resultado.contains("MUERTO")) {
						bomberman2.vidas--;
					}else if (resultado.contains("BOMBA")) {
						//recorrer tablero
						//casilla correcta
						Casilla aux = casillacorrecta(bomberman2);
						if(!aux.bomba) {
							for (int i = 0; i < tablero.length; i++) {
								for (int j = 0; j < tablero[i].length; j++) {
									if (aux.equals(tablero[i][j])) {
										bombas.add(new Bomba(aux.x, aux.y, bomberman2.name, bomberman2.potencia, i, j));
										tablero[i][j].bomba=true;
										bomberman2.bombas++;
									}
								}
							}
						}
						
					}
				}
				
			}
			System.out.println(resultado.trim());
		}
	}
}
