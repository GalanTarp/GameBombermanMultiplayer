

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ClientConnection extends JFrame implements Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Socket socket;
	private BufferedReader br;
	private Thread hilo;
	private JLabel lblmsg;
	private boolean fin=false;
	private int njugador;
	private static final int PORTSERVER = 6000;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientConnection frame = new ClientConnection();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClientConnection() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Join Game");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				join();
			}
		});
		btnNewButton.setBounds(5, 5, 440, 29);
		contentPane.add(btnNewButton);
		
		lblmsg = new JLabel();
		lblmsg.setBounds(15, 46, 429, 16);
		contentPane.add(lblmsg);
		
	}

	protected void join() {
		try {
			socket = new Socket("192.168.1.110", PORTSERVER);
		} catch (UnknownHostException e) {
			lblmsg.setText(e.getMessage());
		} catch (IOException e) {
			lblmsg.setText(e.getMessage());
		}
	
	    // Creamos los streams de entrada/salida
		try {
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Imposible crear canal de comunicación....");
			System.exit(0);
		}
		
		// Lanzamos el hilo que se va a encargar de escuchar todo lo que el server nos envíe
		// Recordamos que el hilo es la propia clase runnable (this)
		hilo = new Thread(this);
		hilo.start();
		
	}

	@Override
	public void run() {
		while (!fin) {
			try {
				String cadena = br.readLine();
				if (cadena!=null) {
					lblmsg.setText(cadena);
					if (cadena.contains("aceptada")){
						String[] split = cadena.split(":");
						njugador = Integer.parseInt(split[1]);	
					} else if (cadena.contains("started")) {
						fin = true;
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// Comienza el juego
		new ClientGame(njugador);	
		setVisible(false);
		dispose();
	}

}
